//package Dumper;
//
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileReader;
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//
//import MainProject.LoadProperties;
//import Parser.CountTagInAscii;
//
//public class DumpRecordAscii {
//	
//	String Delimiter = LoadProperties.properties.getProperty("Delimiter");
//	public void dumpFileChoose(File pathDestination, String fileName) throws IOException {
//
//		
//		
//		File file = null;
//		if (pathDestination != null && pathDestination.isDirectory()) {
//			File[] content = pathDestination.listFiles();
//
//			for (int i = 0; i < content.length; i++) {
//				if (content != null) {
//					file = content[i];
//					fileName = file.getName();
//					
//					
//
//					int index = fileName.lastIndexOf(".");
//					if (index > 0) {
//						String extinsion = fileName.substring(index + 1);
//						if(extinsion.endsWith("ASCII")) {
//							CountTagInAscii ascii = new CountTagInAscii();
//							
//							ascii.countTagInAscii(file, fileName);
//
//						}
//					}
//				}
//			}
//		}
//	}
//	
//	
//	
//	public void getOrder (String pathReadFile, String delimiter, String nameReadFile) {
//		
//		String myDriver = "com.mysql.cj.jdbc.Driver";
//		String myUrl = "jdbc:mysql://localhost:3306/filedumper";
//
//		try {
//
//			Class.forName(myDriver);
//			Connection conn = DriverManager.getConnection(myUrl, "root", "root");
//
////			String query = "SELECT ORDER FROM filedumper.fdm_template_file WHERE TYPE_ID = 3 and IS_CONDITIONAL_TAG = true";
//			String query = "SELECT ORDER FROM filedumper.fdm_template_file WHERE TYPE_ID = 3 and IS_CONDITIONAL_TAG = true";
//
//			Statement st = conn.createStatement();
//
//			// execute the query
//			@SuppressWarnings("unused")
//			ResultSet resultSet = st.executeQuery(query);
//
//			readAscii(pathReadFile, delimiter, nameReadFile);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	
//	public void readAscii(String pathReadFile, String delimiter, String nameReadFile) {
//		
//		int count = 0;
//		String tracingID = "";
//		String path = pathReadFile;
//		long numberOfCdr;
//		boolean condition = true;
//		try {
//			Path path2 = Paths.get(pathReadFile);
//			numberOfCdr = Files.lines(path2).count();
//
//			String myDriver = "com.mysql.cj.jdbc.Driver";
//			String myUrl = "jdbc:mysql://localhost:3306/filedumper";
//
//			Class.forName(myDriver);
//			Connection conn = DriverManager.getConnection(myUrl, "root", "root");
//			String data = "insert into fdm_ascii_dumper (RecordType,IMSI,MSISDN,CalledMSISDN,StartTime,EndTime,Duration) values (?, ?, ?, ?, ?,?,?)";
//			PreparedStatement preparedStatement = conn.prepareStatement(data);
//
//			try (BufferedReader reader = new BufferedReader(new FileReader(pathReadFile))) {
//
//				String line = "";
//
//				while ((line = reader.readLine()) != null) {
//					String[] fields = line.split(Delimiter);
////					System.err.println(Arrays.asList(fields));			
//					int firstIndex = pathReadFile.indexOf('_');
//					int lastIndex = pathReadFile.lastIndexOf('.');
//					if (firstIndex > 0 && lastIndex > 0) {
//						tracingID = pathReadFile.substring(firstIndex + 1, lastIndex);
//
//					}
//
//					if (fields[fields.length - 1].toLowerCase().contains("ascii")) {
//						conn.setAutoCommit(false);
//
//						addBatch(fields, preparedStatement);
//					} 
////						else if(fields[fields.length - 1].toLowerCase().contains("ASCII")) {
////						conn.setAutoCommit(true);
////						
////						AsciiData(fields , conn);
////					}
//
//				}
//				
//			}
//			if (!conn.getAutoCommit()) {
//
//				preparedStatement.executeBatch();
//				conn.commit();
//			}
//			
//			conn.close();
//
//
//			
//			count++;
//			
//			
//		} catch (IOException | SQLException | ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.getStackTrace();
//
//		}
//	}
//	
//	public void addBatch(String[] values, PreparedStatement preparedStatement) throws SQLException {
//
//		preparedStatement.setString(1, values[0]);
//		preparedStatement.setString(2, values[1]);
//		preparedStatement.setString(3, values[2]);
//		preparedStatement.setString(4, values[3]);
//		preparedStatement.setString(5, values[4]);
//
//		preparedStatement.setString(6, values[5]);
//		preparedStatement.setString(7, values[6]);
//		
//
//		preparedStatement.addBatch();
//
//	}
//}
