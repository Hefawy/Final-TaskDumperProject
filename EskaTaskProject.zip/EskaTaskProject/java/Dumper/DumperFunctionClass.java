package Dumper;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public class DumperFunctionClass {

	public void dumperFunctionClass(File pathValidator, File pathDumper,String Delimiter) throws IOException, NumberFormatException, ClassNotFoundException, SQLException {

		LoadSetupTablesInDum.loadTablesFromDatabaseFromDum();

		MoverClassToDumper classToDumper = new MoverClassToDumper();
		classToDumper.moverClassToDumper(pathValidator, pathDumper);

		ReadOutFile file = new ReadOutFile();
		file.readFileOut(pathDumper);

		RejLine rejLine = new RejLine();
		rejLine.listFileRejected(pathDumper , pathDumper.getName());
		
//		DumpRecordAscii dumpRecordAscii = new DumpRecordAscii();
//		dumpRecordAscii.dumpFileChoose(pathDestination , pathSource.getName());
		System.err.println("Dumper Done");
	}
}
