package Dumper;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;


public class RejLine {
	
	@SuppressWarnings("unused")
	public void listFileRejected(File pathDumper, String fileName) throws NumberFormatException, ClassNotFoundException, SQLException, IOException {
		
		File file = null;
		if (pathDumper != null && pathDumper.isDirectory()) {
			File[] content = pathDumper.listFiles();

			for (int i = 0; i < content.length; i++) {
				if (content != null) {
					file = content[i];
					fileName = file.getName();
					
					

					int index = fileName.lastIndexOf(".");
					if (index > 0) {
						String extinsion = fileName.substring(index + 1);
						if (fileName.startsWith("REJECTED")) {
							TestClass class1 = new TestClass();
							class1.readAndLoad(file, fileName);
						}
					}
				}
			}
		}

	}}
