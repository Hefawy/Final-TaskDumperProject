package Dumper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestClass {

	public void readAndLoad(File Dumper, String fileName) throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		
//		System.out.println("Print DUMP REJECTED");
		
	// Step 1: Connect to the database
		String myDriver = "com.mysql.cj.jdbc.Driver";
		String myUrl = "jdbc:mysql://localhost:3306/filedumper";
		Class.forName(myDriver);
		Connection conn = DriverManager.getConnection(myUrl, "root", "root");

		// Step 2: Create a PreparedStatement
		String sql = "INSERT INTO fdm_rejected_dumber (CDR, FILE_NAME, CREATE_DATE) VALUES (?, ?, ?)";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);

		// Step 3: Use a BufferedReader to read the file
		BufferedReader reader = new BufferedReader(new FileReader(Dumper));

		// Step 4: Read the file line by line
		String line;
		while ((line = reader.readLine()) != null) {
		    String[] fields = line.split(","); // Split the line using a comma as the delimiter
		    
		    // Step 5: Set the values of the fields as parameters in the Prepared Statement
		    preparedStatement.setString(1, "gggggg");
		    preparedStatement.setString(2, fileName);
		    preparedStatement.setString(3, time());
		    
		    // Step 6: Add the Prepared Statement to a batch
		    preparedStatement.addBatch();
		}

		// Step 7: Execute the batch
		preparedStatement.executeBatch();

		// Step 8: Close the BufferedReader and the Prepared Statement
		reader.close();
		preparedStatement.close();
		
	}
	
	public String time() {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime localDateTime = LocalDateTime.now();
		String dateTime = dateTimeFormatter.format(localDateTime);
		return dateTime;
	}
}
