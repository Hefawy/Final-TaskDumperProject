package Parser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

import org.apache.commons.io.FilenameUtils;

import MainProject.LoadProperties;

public class CountTagInAscii {

	BufferedWriter bufferedWriter;
	PrintWriter printWriter;
	String fileName;
	File pathDestination = new File(LoadProperties.properties.getProperty("DestinationFilePath"));
	List<String[]> saveLines = new ArrayList<>();
	List<String> Lines = new ArrayList<>();
	LinkedHashMap<String, FDMTemplateFileModel> map = new LinkedHashMap<>();
	String Delimiter = LoadProperties.properties.getProperty("Delimiter");

	Random random = new Random();
	int randomNumber = random.nextInt(999999);
	int words = 0;
	static boolean isRejected = false;

	String CreationBy = "dd";

	DumpFileAsciiToDatabase rejectedLine = new DumpFileAsciiToDatabase();
	File parserPath = new File(LoadProperties.properties.getProperty("ParserFilepath"));

	ArrayList<FDMTemplateFileModel> v = new ArrayList<>();

	public void countTagInAscii(File Destination, String fileName) throws IOException {
		this.fileName = fileName;

		v = LoadSetupTables.loadTemplateForTypeID(3);

		for (int i = 0; i < v.size(); i++) {

			map.put(i + "", v.get(i));

		}
		// TODO here
		words = map.keySet().size() - 1;

		String line;

		FileReader file = new FileReader(Destination);
		try (BufferedReader br = new BufferedReader(file)) {
			String[] wordsInFile = null;

			while ((line = br.readLine()) != null) {

				wordsInFile = line.split(",");
				saveLines.add(wordsInFile);
				Lines.add(line);

				// numberOfTags = words*********
				if ((wordsInFile.length > words || wordsInFile.length < words) && !line.equals("")) {
					saveToDb(line);
				} else if (wordsInFile.length == words) {

					File file3 = new File(getsucssccFileName());
					bufferedWriter = new BufferedWriter(new FileWriter(file3, true));

					printWriter = new PrintWriter(bufferedWriter);

					bufferedWriter.write(line);
					bufferedWriter.write("");
					bufferedWriter.write(Delimiter);
					bufferedWriter.write(fileName);
					bufferedWriter.newLine();
					bufferedWriter.flush();
					bufferedWriter.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void saveToDb(String rejLine) throws IOException {

		isRejected = true;
		rejectedLine.sendQueryToTableAsciiRejected(rejLine, fileName, randomNumber, CreationBy);

	}

	private String getsucssccFileName() {

		String extentionPrs = ".prs";

		String FileName = fileName;
		String sourceName = FilenameUtils.removeExtension(FileName);

		String sourceNameAscii = parserPath + "/" + sourceName + extentionPrs;

		return sourceNameAscii;
	}

}
